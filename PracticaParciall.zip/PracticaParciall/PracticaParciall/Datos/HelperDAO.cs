﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PracticaParciall.Datos
{
    public class HelperDAO
    {
        SqlConnection conexion;
        SqlCommand comando;
        private static HelperDAO instance;

        public HelperDAO()
        {
            conexion = new SqlConnection(Properties.Resources.CadenaConexion);
            comando = new SqlCommand();
        }

        public void Conectar()
        {
            conexion.Open();
            comando.Connection = conexion;
            comando.CommandType = CommandType.StoredProcedure;
        }

        public void Desconectar()
        {
            conexion.Close();
        }

        public static HelperDAO GetIntance()
        {
            if(instance == null)
            {
                instance = new HelperDAO();
            }

            return instance;
        }

        public DataTable ComboBox(string sp)
        {
            DataTable table = new DataTable();
            Conectar();
            comando.CommandText = sp;
            table.Load(comando.ExecuteReader());
            Desconectar();
            return table;
        }

        public SqlConnection connection()
        {
            return conexion;
        }

    }
}
