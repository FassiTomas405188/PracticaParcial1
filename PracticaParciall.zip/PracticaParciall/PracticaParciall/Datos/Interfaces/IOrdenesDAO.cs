﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PracticaParciall.Dominio;

namespace PracticaParciall.Datos.Interfaces
{
    public interface IOrdenesDAO
    {
        List<Material> GetMateriales();

        bool ObtenerMaestroDetalle(OrdenRetiro oOrdenRetiro);

        bool ObtenerStock(int lCantidad, Material lMaterial);

        int ObtenerNroOrden();


    }
}
