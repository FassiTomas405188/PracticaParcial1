﻿using System;
using PracticaParciall.Datos.Implementacion;
using PracticaParciall.Dominio;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using PracticaParciall.Datos.Interfaces;
using System.Data;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace PracticaParciall.Datos.Implementacion
{
    public class OrdenesDAO : IOrdenesDAO
    {
        SqlConnection conexion = HelperDAO.GetIntance().connection();
        SqlCommand comando = new SqlCommand();

        SqlTransaction trans = null;
        int nroOrden = 0;

        public List<Material> GetMateriales()
        {
            List<Material> list = new List<Material>();
            DataTable table = HelperDAO.GetIntance().ComboBox("SP_CONSULTAR_MATERIALES");

            foreach (DataRow fila in table.Rows)
            {
                int codigo = Convert.ToInt32(fila["Codigo"]);
                string nombre = (fila["Nombre"].ToString());
                int stock = Convert.ToInt32(fila["Stock"]);

                Material material = new Material(codigo, nombre, stock);
                list.Add(material);
            }

            return list;
        }

        public bool ObtenerStock(int lCantidad, Material lMaterial)
        {
            bool resultado;
            if(lCantidad > lMaterial.stockM)
            {
                resultado = false;
            }
            else
            {
                return true;
            }

            return resultado;
        }

        public int ObtenerNroOrden()
        {
            return nroOrden;
        }

        public void commandTransaction()
        {
            conexion.Open();
            comando.Connection = conexion;
            comando.CommandType = CommandType.StoredProcedure;

            trans = conexion.BeginTransaction();
            comando.Transaction = trans;
            comando.CommandText = "SP_INSERTAR_ORDEN";
        }

        public bool ObtenerMaestroDetalle(OrdenRetiro oOrden)
        {
            bool resultado;

            try
            {
                commandTransaction();
                comando.Parameters.AddWithValue("@responsable", oOrden.responsableOrden);
                SqlParameter parametro = new SqlParameter("@nro", SqlDbType.Int);
                parametro.Direction = ParameterDirection.Output;

                comando.Parameters.Add(parametro);
                comando.ExecuteNonQuery();

                nroOrden = (int)parametro.Value;
                int detalleOrden = 0;

                SqlCommand commandDetalle;

                foreach (DetalleOrden orden in oOrden.listaDetalles)
                {
                    commandDetalle = new SqlCommand("SP_INSERTAR_DETALLES", conexion, trans);
                    commandDetalle.CommandType = CommandType.StoredProcedure;

                    commandDetalle.Parameters.AddWithValue("@nro_Orden", nroOrden);
                    commandDetalle.Parameters.AddWithValue("@detalle", ++detalleOrden);
                    commandDetalle.Parameters.AddWithValue("@codigo", orden.material.codigo);
                    commandDetalle.Parameters.AddWithValue("@cantidad", orden.cantidad);

                    commandDetalle.ExecuteNonQuery();
                }

                trans.Commit();
                resultado = true;
            }
            catch
            {
                trans.Rollback();
                resultado = false;
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }

            return resultado;
        }
    }
}
