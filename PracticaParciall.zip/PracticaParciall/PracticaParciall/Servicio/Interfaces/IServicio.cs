﻿using System;
using PracticaParciall.Dominio;
using PracticaParciall.Servicio.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaParciall.Servicio.Interfaces
{
    public interface IServicio
    {
        List<Material> TraerMateriales();

        bool TraerMaestroDetalle(OrdenRetiro oOrdenRetiro);

        bool TraerStock(int lCantidad, Material lMaterial);

        int TraerNroOrden();
    }
}
