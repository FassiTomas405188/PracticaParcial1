﻿using PracticaParciall.Datos.Interfaces;
using PracticaParciall.Datos.Implementacion;
using PracticaParciall.Dominio;
using PracticaParciall.Servicio.Interfaces;
using PracticaParciall.Servicio.Implementacion;
using PracticaParciall.Servicio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaParciall.Servicio.Implementacion
{
    public class Servicio : IServicio
    {
        private IOrdenesDAO dao;

        public Servicio()
        {
            dao = new OrdenesDAO();
        }
        public List<Material> TraerMateriales()
        {
           return dao.GetMateriales();
        }

       public bool TraerMaestroDetalle(OrdenRetiro oOrdenRetiro)
        {
            return dao.ObtenerMaestroDetalle(oOrdenRetiro);
        }

        public bool TraerStock(int lCantidad, Material lMaterial)
        {
            return dao.ObtenerStock(lCantidad, lMaterial);
        }

        public int TraerNroOrden()
        {
            return dao.ObtenerNroOrden();
        }
    }
}
