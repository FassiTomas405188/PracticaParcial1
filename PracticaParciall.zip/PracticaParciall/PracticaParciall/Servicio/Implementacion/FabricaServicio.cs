﻿using PracticaParciall.Servicio.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaParciall.Servicio.Implementacion
{
    public class FabricaServicio : IFabricaServicio
    {
        public IServicio CrearNuevoServicio()
        {
            return new Servicio();
        }
    }
}
