﻿using System;
using PracticaParciall.Datos.Interfaces;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using PracticaParciall.Servicio.Interfaces;
using PracticaParciall.Dominio;
using PracticaParciall.Datos;
using System.Runtime.InteropServices;

namespace PracticaParciall
{
    public partial class Ordenes : Form
    {
        IServicio oServicio;
        OrdenRetiro oOrden;
        public Ordenes(IFabricaServicio fabricaServicio)
        {
            InitializeComponent();
            oOrden = new OrdenRetiro();
            oServicio = fabricaServicio.CrearNuevoServicio();
        }
        private void cargarCombo()
        {
            cboMaterial.DataSource = oServicio.TraerMateriales();
            cboMaterial.ValueMember = "codigo";
            cboMaterial.DisplayMember = "nombre";
            cboMaterial.SelectedIndex = -1;
        }

        private void bttnCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        public bool validar()
        {
            bool resultado = true;

            if (String.IsNullOrEmpty(txtResponsable.Text))
            {
                MessageBox.Show("Error, debe ingresar un responsable!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtResponsable.Focus();
                resultado = false;
            }
            else
               if (String.Empty.Equals(cboMaterial.Text))
            {
                MessageBox.Show("Error, debe seleccionar un material!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cboMaterial.Focus();
                resultado = false;
            }
            else
                if (String.IsNullOrEmpty(txtCantidad.Text))
            {
                MessageBox.Show("Error, debe ingresar una cantidad!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCantidad.Focus();
                resultado = false;
            }
            else
                if (!oServicio.TraerStock(Convert.ToInt32(txtCantidad.Text), (Material)cboMaterial.SelectedItem))
            {
                MessageBox.Show("Error, no hay stock disponible!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                resultado = false;
            }
            foreach (DataGridViewRow item in dgvNuevaOrden.Rows)
            {
                if (item.Cells["Material"].Value.ToString().Equals(txtCantidad.Text))
                {
                    MessageBox.Show("Error, ya existe el material!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    resultado = false;
                }
            }

            return resultado;
        }

        private void bttnAgregar_Click(object sender, EventArgs e)
        {
            if (validar() is true)
            {
                Material material = (Material)cboMaterial.SelectedItem;
                int cantidad = Convert.ToInt32(txtCantidad.Text);

                DetalleOrden oDetalle = new DetalleOrden(material, cantidad);

                oOrden.AgregarDetalle(oDetalle);
                dgvNuevaOrden.Rows.Add(new object[] {material.nombre, material.stockM, cantidad});
            }
        }

        private void dgvNuevaOrden_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvNuevaOrden.CurrentCell.ColumnIndex == 3)
            {
                oOrden.QuitarDetalle(dgvNuevaOrden.CurrentRow.Index);
                dgvNuevaOrden.Rows.Remove(dgvNuevaOrden.CurrentRow);
            }
        }

        private bool ValidarAceptar()
        {
            bool validar = true;

            if (dgvNuevaOrden.Rows.Count == 0)
            {
                MessageBox.Show("Error, debe ingresar al menos un material..", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                validar = false;
            }

            return validar;
        }

        private void Ordenes_Load_1(object sender, EventArgs e)
        {
            cargarCombo();
        }

        private void bttnAceptar_Click_1(object sender, EventArgs e)
        {
            if (ValidarAceptar() is true)
            {
                oOrden.responsableOrden = txtResponsable.Text;
                oOrden.fechaOrden = Convert.ToDateTime(dtpFecha.Text);

                if (oServicio.TraerMaestroDetalle(oOrden) is true)
                {
                    MessageBox.Show("Se cargó con éxito la orden nro " +
                        oServicio.TraerNroOrden() + " !", "INFO", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    this.Dispose();
                }
                else
                {
                    MessageBox.Show("Ocurrio un error en la carga..", "ERROR",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
