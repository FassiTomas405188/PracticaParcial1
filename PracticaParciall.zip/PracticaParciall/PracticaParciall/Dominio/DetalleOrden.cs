﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaParciall.Dominio
{
    public class DetalleOrden
    {
        public Material material { get; set; }
        public int cantidad { get; set; }

        public DetalleOrden()
        {
            material = new Material();
            cantidad = 0;
        }

        public DetalleOrden(Material mat, int cant)
        {
            material = mat;
            cantidad = cant;
        }
    }
}
