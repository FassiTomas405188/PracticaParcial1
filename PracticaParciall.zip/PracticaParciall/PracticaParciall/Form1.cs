﻿using PracticaParciall.Servicio.Implementacion;
using PracticaParciall.Servicio.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticaParciall
{
    public partial class Form1 : Form
    {
        private IFabricaServicio lfabrica;
        public Form1(IFabricaServicio fabricaServicio)
        {
            InitializeComponent();
            this.lfabrica = fabricaServicio;
        }

        private void nuevaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ordenes lnuevo = new Ordenes(lfabrica);
            lnuevo.ShowDialog();
        }
    }
}
